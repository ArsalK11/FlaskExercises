from flask import Flask, render_template, request

app = Flask(__name__,template_folder=".")
#Set route to GET
@app.route('/', methods=['GET'])
def home():
    #Return the render template for home.html
    return render_template('home.html')
#Another route for get
@app.route('/result', methods=['GET'])
def result():
    #Set number for a request
    number = request.args.get('number')
    #If not a number redirect to error.html
    if not number:
        return render_template('error.html')
    try:
        #Calculate if number is even or dd
        number = int(number)
        if number % 2 == 0:
            result = 'even'
        else:
            result = 'odd'
            #Redirect the result to result.html
        return render_template('result.html', result=result)
    except ValueError:
        return render_template('error.html')

if __name__ == '__main__':
    app.run(debug=True)
